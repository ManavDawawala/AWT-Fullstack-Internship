var month="July";
switch(month)
{
    case "June":
        document.write("Sixth month");
        break;
    case "July":
        document.write("Seventh month");
        break;    
}
var a=true;
switch(a)
{
    case true:
        document.write(1);
}