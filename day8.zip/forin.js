const Human= {Firstname:"Manav",LastName:"Dawawala",age:"20"};
for (let H in Human) {
    document.write("<br/>"+H);
}
document.write("<hr/>");
for (let H in Human) {
    document.write("<br/>"+Human[H]);
}
